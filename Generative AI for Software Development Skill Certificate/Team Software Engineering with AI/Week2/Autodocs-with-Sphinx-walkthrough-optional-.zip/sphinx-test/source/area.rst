area module
============

.. automodule:: area
    :members:

